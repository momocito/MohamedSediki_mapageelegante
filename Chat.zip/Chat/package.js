{ 
    "name": "socket",
    "version": "1.0.0",
    "description": "Creer une page web avec le module de chat-live",
    "main": "index.js",
    "scripts": {
      "test": "echo \"Error: no test specified\" && exit 1"
    },
    "author": "That one guy Anto1",
    "license": "ISC",
    "dependencies": {
      "express": "^4.18.2",
      "socket.io": "^4.7.2"
    }
  }